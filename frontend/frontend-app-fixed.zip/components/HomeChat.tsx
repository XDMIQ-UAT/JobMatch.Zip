'use client'

import { useState, useRef, useEffect } from 'react'

interface Message {
  id: string
  type: 'bot' | 'user'
  content: string
  timestamp: Date
  authProviders?: Array<{ id: string; name: string; icon: string }>
}

const AUTH_PROVIDERS = [
  { id: 'linkedin', name: 'LinkedIn', icon: '💼' },
  { id: 'microsoft', name: 'Microsoft', icon: '🪟' },
  { id: 'facebook', name: 'Facebook', icon: '📘' },
  { id: 'google', name: 'Google', icon: '🔍' },
  { id: 'apple', name: 'Apple', icon: '🍎' },
  { id: 'email', name: 'Email', icon: '📧' },
  { id: 'sms', name: 'SMS/VoIP', icon: '📱' }
]

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api'

export default function HomeChat() {
  const [messages, setMessages] = useState<Message[]>([])
  const [inputValue, setInputValue] = useState('')
  const [loading, setLoading] = useState(false)
  const [sessionId, setSessionId] = useState<string | null>(null)
  const [authenticated, setAuthenticated] = useState(false)
  const messagesContainerRef = useRef<HTMLDivElement>(null)
  const [isInitialLoad, setIsInitialLoad] = useState(true)

  const scrollToBottom = () => {
    // Only scroll the messages container, not the entire page
    if (messagesContainerRef.current) {
      messagesContainerRef.current.scrollTop = messagesContainerRef.current.scrollHeight
    }
  }

  useEffect(() => {
    // Don't scroll on initial load - only scroll when messages are added after user interaction
    if (!isInitialLoad && messages.length > 0) {
      // Use requestAnimationFrame to prevent scroll jump
      requestAnimationFrame(() => {
        scrollToBottom()
      })
    }
  }, [messages.length, isInitialLoad]) // Only trigger on length change, not content

  // Initialize with welcome message
  useEffect(() => {
    if (messages.length === 0) {
      const welcomeMessage: Message = {
        id: 'welcome',
        type: 'bot',
        content: "Hi there! 👋 Welcome to JobMatch - the first job matching platform for LLC owners who work with AI. I'm here to help you discover opportunities that match your capabilities.\n\nTo get started, let's set up your anonymous identity. Your privacy is protected - we'll never reveal your real identity. Which authentication method would you prefer?",
        timestamp: new Date(),
        authProviders: AUTH_PROVIDERS
      }
      setMessages([welcomeMessage])
    }
  }, [])

  const handleAuthProviderClick = async (providerId: string) => {
    setLoading(true)
    
    // Add user message
    const provider = AUTH_PROVIDERS.find(p => p.id === providerId)
    const userMessage: Message = {
      id: `user-${Date.now()}`,
      type: 'user',
      content: `I'd like to authenticate with ${provider?.name}`,
      timestamp: new Date()
    }
    setMessages(prev => [...prev, userMessage])

    // Add bot response
    setTimeout(() => {
      const botMessage: Message = {
        id: `bot-${Date.now()}`,
        type: 'bot',
        content: `Great choice! Let's get you authenticated with ${provider?.name}. Redirecting you to the authentication page...`,
        timestamp: new Date()
      }
      setMessages(prev => [...prev, botMessage])
      
      // Redirect to auth page after a moment
      setTimeout(() => {
        window.location.href = `/auth?provider=${providerId}`
      }, 1500)
    }, 500)
  }

  const handleSendMessage = async () => {
    if (!inputValue.trim() || loading) return

    const userMessage: Message = {
      id: `user-${Date.now()}`,
      type: 'user',
      content: inputValue,
      timestamp: new Date()
    }
    setMessages(prev => [...prev, userMessage])
    setInputValue('')
    setLoading(true)

    // Simulate bot response
    setTimeout(() => {
      let botResponse = ""
      const lowerInput = inputValue.toLowerCase()
      
      if (lowerInput.includes('login') || lowerInput.includes('sign in') || lowerInput.includes('authenticate')) {
        botResponse = "Perfect! Let's get you authenticated. Choose your preferred method below:"
      } else if (lowerInput.includes('help') || lowerInput.includes('what') || lowerInput.includes('how')) {
        botResponse = "I'm here to help you find job opportunities that match your AI capabilities! First, we need to verify your identity (anonymously). Once authenticated, you can take assessments, find matches, and connect with opportunities. Ready to get started?"
      } else {
        botResponse = "That's great! To get the most out of JobMatch, let's start by authenticating your anonymous identity. This helps us match you with the right opportunities while keeping your privacy protected. Which authentication method would you prefer?"
      }

      const botMessage: Message = {
        id: `bot-${Date.now()}`,
        type: 'bot',
        content: botResponse,
        timestamp: new Date(),
        authProviders: !authenticated ? AUTH_PROVIDERS : undefined
      }
      setMessages(prev => [...prev, botMessage])
      setLoading(false)
    }, 800)
  }

  return (
    <div style={{
      display: 'flex',
      flexDirection: 'column',
      height: '600px',
      maxWidth: '800px',
      margin: '0 auto',
      backgroundColor: '#fff',
      borderRadius: '12px',
      boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
      border: '1px solid #e0e0e0',
      overflow: 'hidden'
    }}>
      {/* Chat Header */}
      <div style={{
        padding: '1rem 1.5rem',
        backgroundColor: '#2196f3',
        color: 'white',
        display: 'flex',
        alignItems: 'center',
        gap: '0.75rem',
        borderBottom: '1px solid #1976d2'
      }}>
        <div style={{
          width: '40px',
          height: '40px',
          borderRadius: '50%',
          backgroundColor: 'rgba(255, 255, 255, 0.2)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          fontSize: '1.5rem'
        }}>
          💬
        </div>
        <div>
          <div style={{ fontWeight: '600', fontSize: '1rem' }}>JobMatch Assistant</div>
          <div style={{ fontSize: '0.75rem', opacity: 0.9 }}>Ready to help you find opportunities</div>
        </div>
      </div>

      {/* Messages Area */}
      <div 
        ref={messagesContainerRef}
        style={{
          flex: 1,
          overflowY: 'auto',
          overflowX: 'hidden',
          padding: '1.5rem',
          display: 'flex',
          flexDirection: 'column',
          gap: '1rem',
          backgroundColor: '#f5f5f5',
          scrollBehavior: 'smooth'
        }}
      >
        {messages.map((msg) => (
          <div
            key={msg.id}
            style={{
              display: 'flex',
              justifyContent: msg.type === 'user' ? 'flex-end' : 'flex-start',
              alignItems: 'flex-start',
              gap: '0.75rem'
            }}
          >
            {msg.type === 'bot' && (
              <div style={{
                width: '36px',
                height: '36px',
                borderRadius: '50%',
                backgroundColor: '#2196f3',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '1.25rem',
                flexShrink: 0
              }}>
                🤖
              </div>
            )}
            <div style={{
              maxWidth: '70%',
              padding: '0.75rem 1rem',
              borderRadius: '12px',
              backgroundColor: msg.type === 'user' ? '#2196f3' : '#fff',
              color: msg.type === 'user' ? 'white' : '#333',
              boxShadow: '0 1px 2px rgba(0, 0, 0, 0.1)',
              whiteSpace: 'pre-wrap',
              lineHeight: '1.5',
              fontSize: '0.9375rem'
            }}>
              {msg.content}
            </div>
            {msg.type === 'user' && (
              <div style={{
                width: '36px',
                height: '36px',
                borderRadius: '50%',
                backgroundColor: '#e0e0e0',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '1.25rem',
                flexShrink: 0
              }}>
                👤
              </div>
            )}
          </div>
        ))}

        {/* Auth Providers */}
        {messages.length > 0 && messages[messages.length - 1].authProviders && (
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(120px, 1fr))',
            gap: '0.75rem',
            marginTop: '0.5rem',
            padding: '0.75rem',
            backgroundColor: '#fff',
            borderRadius: '8px',
            border: '1px solid #e0e0e0'
          }}>
            {messages[messages.length - 1].authProviders?.map((provider) => (
              <button
                key={provider.id}
                onClick={() => handleAuthProviderClick(provider.id)}
                disabled={loading}
                style={{
                  padding: '0.75rem',
                  border: '1px solid #e0e0e0',
                  borderRadius: '8px',
                  background: 'white',
                  cursor: loading ? 'not-allowed' : 'pointer',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  gap: '0.5rem',
                  transition: 'all 0.2s ease',
                  opacity: loading ? 0.6 : 1
                }}
                onMouseEnter={(e) => {
                  if (!loading) {
                    e.currentTarget.style.background = '#e3f2fd'
                    e.currentTarget.style.borderColor = '#2196f3'
                    e.currentTarget.style.transform = 'translateY(-2px)'
                  }
                }}
                onMouseLeave={(e) => {
                  if (!loading) {
                    e.currentTarget.style.background = 'white'
                    e.currentTarget.style.borderColor = '#e0e0e0'
                    e.currentTarget.style.transform = 'translateY(0)'
                  }
                }}
              >
                <span style={{ fontSize: '1.5rem' }}>{provider.icon}</span>
                <span style={{ fontSize: '0.75rem', fontWeight: '500' }}>{provider.name}</span>
              </button>
            ))}
          </div>
        )}

        {loading && messages[messages.length - 1]?.type === 'user' && (
          <div style={{
            display: 'flex',
            justifyContent: 'flex-start',
            alignItems: 'flex-start',
            gap: '0.75rem'
          }}>
            <div style={{
              width: '36px',
              height: '36px',
              borderRadius: '50%',
              backgroundColor: '#2196f3',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: '1.25rem',
              flexShrink: 0
            }}>
              🤖
            </div>
            <div style={{
              padding: '0.75rem 1rem',
              borderRadius: '12px',
              backgroundColor: '#fff',
              color: '#666',
              fontSize: '0.875rem'
            }}>
              Thinking...
            </div>
          </div>
        )}
      </div>

      {/* Input Area */}
      <div style={{
        padding: '1rem 1.5rem',
        backgroundColor: '#fff',
        borderTop: '1px solid #e0e0e0',
        display: 'flex',
        gap: '0.75rem',
        alignItems: 'center'
      }}>
        <input
          type="text"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          onKeyPress={(e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
              e.preventDefault()
              handleSendMessage()
            }
          }}
          placeholder="Type your message or ask about authentication..."
          disabled={loading}
          style={{
            flex: 1,
            padding: '0.75rem 1rem',
            border: '1px solid #e0e0e0',
            borderRadius: '8px',
            fontSize: '0.9375rem',
            outline: 'none',
            transition: 'border-color 0.2s ease'
          }}
          onFocus={(e) => e.currentTarget.style.borderColor = '#2196f3'}
          onBlur={(e) => e.currentTarget.style.borderColor = '#e0e0e0'}
        />
        <button
          onClick={handleSendMessage}
          disabled={loading || !inputValue.trim()}
          style={{
            padding: '0.75rem 1.5rem',
            backgroundColor: loading || !inputValue.trim() ? '#ccc' : '#2196f3',
            color: 'white',
            border: 'none',
            borderRadius: '8px',
            cursor: loading || !inputValue.trim() ? 'not-allowed' : 'pointer',
            fontWeight: '600',
            fontSize: '0.9375rem',
            transition: 'background-color 0.2s ease'
          }}
        >
          Send
        </button>
      </div>
    </div>
  )
}

