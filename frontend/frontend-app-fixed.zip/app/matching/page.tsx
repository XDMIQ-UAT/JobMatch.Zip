'use client'

import { useState } from 'react'

export default function MatchingPage() {
  const [userId, setUserId] = useState('')
  const [matches, setMatches] = useState<any[]>([])
  const [loading, setLoading] = useState(false)

  const handleGenerateMatches = async () => {
    if (!userId) {
      alert('Please create an anonymous identity first')
      return
    }

    setLoading(true)
    try {
      const response = await fetch(`http://localhost:8000/api/matching/generate/${userId}?limit=10`, {
        method: 'POST'
      })
      const data = await response.json()
      setMatches(data)
    } catch (error) {
      console.error('Matching failed:', error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <main style={{ padding: '2rem', maxWidth: '1000px', margin: '0 auto' }}>
      <h1>AI-Powered Matching</h1>
      <p>Find opportunities based on what you CAN do, not credentials</p>

      <div style={{ marginTop: '2rem' }}>
        <label>
          Anonymous User ID:
          <input
            type="text"
            value={userId}
            onChange={(e) => setUserId(e.target.value)}
            style={{ width: '100%', padding: '0.5rem', marginTop: '0.5rem' }}
          />
        </label>
      </div>

      <button
        onClick={handleGenerateMatches}
        disabled={loading}
        style={{ marginTop: '1rem', padding: '0.75rem 1.5rem', fontSize: '1rem' }}
      >
        {loading ? 'Generating Matches...' : 'Generate Matches'}
      </button>

      {matches.length > 0 && (
        <div style={{ marginTop: '2rem' }}>
          <h2>Your Matches</h2>
          {matches.map((match) => (
            <div key={match.match_id} style={{ marginTop: '1rem', padding: '1rem', border: '1px solid #ccc' }}>
              <h3>Match Score: {match.match_score}/100</h3>
              <p>Job Posting ID: {match.job_posting_id}</p>
              {match.match_reasons && (
                <ul>
                  {match.match_reasons.map((reason: string, i: number) => (
                    <li key={i}>{reason}</li>
                  ))}
                </ul>
              )}
              {match.human_reviewed && <p>✓ Human Reviewed</p>}
            </div>
          ))}
        </div>
      )}
    </main>
  )
}


