'use client'

import { useState, useEffect } from 'react'
import AnonymousIdDisplay from '@/components/AnonymousIdDisplay'
import { getApiUrl } from '@/utils/api'

export default function AuthPage() {
  const [authMethod, setAuthMethod] = useState<string | null>(null)
  const [email, setEmail] = useState('')
  const [phone, setPhone] = useState('')
  const [code, setCode] = useState('')
  const [loading, setLoading] = useState(false)
  const [anonymousId, setAnonymousId] = useState<string | null>(null)
  const API_URL = getApiUrl()

  // Handle provider query parameter from chat
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search)
    const provider = urlParams.get('provider')
    if (provider) {
      if (provider === 'email') {
        setAuthMethod('email')
      } else if (provider === 'sms') {
        setAuthMethod('sms')
      } else {
        // Auto-trigger social auth
        handleSocialAuth(provider)
      }
    }
  }, [])

  const providers = [
    { id: 'facebook', name: 'Facebook', icon: '📘' },
    { id: 'linkedin', name: 'LinkedIn', icon: '💼' },
    { id: 'google', name: 'Google', icon: '🔍' },
    { id: 'microsoft', name: 'Microsoft', icon: '🪟' },
    { id: 'apple', name: 'Apple', icon: '🍎' },
    { id: 'email', name: 'Email', icon: '📧' },
    { id: 'sms', name: 'SMS/VoIP', icon: '📱' }
  ]

  const handleSocialAuth = async (provider: string) => {
    setLoading(true)
    try {
      // In production, would redirect to OAuth provider
      // For now, simulate authentication
      const response = await fetch(`${API_URL}/auth/social/authenticate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          provider: provider,
          provider_token: `mock_token_${provider}_${Date.now()}`
        })
      })
      const data = await response.json()
      setAnonymousId(data.anonymous_id)
      setAuthMethod(null)
    } catch (error) {
      console.error('Social auth failed:', error)
      // Show error message but don't block - allow retry
      alert('Authentication failed. Please try again or choose a different method.')
    } finally {
      setLoading(false)
    }
  }

  const sendEmailCode = async () => {
    if (!email) {
      alert('Please enter your email')
      return
    }

    setLoading(true)
    try {
      const response = await fetch(`${API_URL}/auth/social/email/send`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email })
      })
      
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({ detail: 'Failed to send email code' }))
        throw new Error(errorData.detail || `HTTP ${response.status}`)
      }
      
      setAuthMethod('email_verify')
    } catch (error) {
      console.error('Failed to send email code:', error)
      alert(`Failed to send email code: ${error instanceof Error ? error.message : 'Please try again.'}`)
    } finally {
      setLoading(false)
    }
  }

  const verifyEmailCode = async () => {
    setLoading(true)
    try {
      const response = await fetch(`${API_URL}/auth/social/email/verify`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, code })
      })
      const data = await response.json()
      setAnonymousId(data.anonymous_id)
      setAuthMethod(null)
    } catch (error) {
      console.error('Email verification failed:', error)
      alert('Verification failed. Please check your code and try again.')
    } finally {
      setLoading(false)
    }
  }

  const sendSMSCode = async () => {
    if (!phone) {
      alert('Please enter your phone number')
      return
    }

    setLoading(true)
    try {
      await fetch(`${API_URL}/auth/social/sms/send`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone_number: phone })
      })
      setAuthMethod('sms_verify')
    } catch (error) {
      console.error('Failed to send SMS code:', error)
      alert('Failed to send SMS code. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  const verifySMSCode = async () => {
    setLoading(true)
    try {
      const response = await fetch(`${API_URL}/auth/social/sms/verify`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone_number: phone, code })
      })
      const data = await response.json()
      setAnonymousId(data.anonymous_id)
      setAuthMethod(null)
    } catch (error) {
      console.error('SMS verification failed:', error)
      alert('Verification failed. Please check your code and try again.')
    } finally {
      setLoading(false)
    }
  }

  if (anonymousId) {
    return (
      <main style={{ padding: '2rem', maxWidth: '600px', margin: '0 auto' }}>
        <h1 style={{ textAlign: 'center', marginBottom: '1.5rem' }}>Authentication Successful!</h1>
        <AnonymousIdDisplay anonymousId={anonymousId} showTips={true} />
        <div style={{ textAlign: 'center', marginTop: '1.5rem' }}>
          <a href="/" style={{ display: 'inline-block', padding: '0.75rem 1.5rem', background: '#0066cc', color: 'white', textDecoration: 'none', borderRadius: '4px' }}>
            Continue to Platform
          </a>
        </div>
      </main>
    )
  }

  return (
    <main style={{ padding: '2rem', maxWidth: '600px', margin: '0 auto' }}>
      <h1>Authenticate with XDMIQ</h1>
      <p>Choose your authentication method. Your identity remains anonymous.</p>

      {!authMethod && (
        <div style={{ marginTop: '2rem' }}>
          <h2>Social Login</h2>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '1rem', marginTop: '1rem' }}>
            {providers.map(provider => (
              <button
                key={provider.id}
                onClick={() => {
                  if (provider.id === 'email') {
                    setAuthMethod('email')
                  } else if (provider.id === 'sms') {
                    setAuthMethod('sms')
                  } else {
                    handleSocialAuth(provider.id)
                  }
                }}
                disabled={loading}
                style={{
                  padding: '1rem',
                  border: '1px solid #ccc',
                  borderRadius: '8px',
                  background: 'white',
                  cursor: 'pointer',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  gap: '0.5rem'
                }}
              >
                <span style={{ fontSize: '2rem' }}>{provider.icon}</span>
                <span>{provider.name}</span>
              </button>
            ))}
          </div>
          <div style={{ marginTop: '2rem', padding: '1rem', backgroundColor: '#fff3cd', border: '1px solid #ffc107', borderRadius: '8px', textAlign: 'center' }}>
            <p style={{ margin: 0, fontSize: '0.875rem', color: '#856404' }}>
              Lost your anonymous ID?{' '}
              <a 
                href="/recover" 
                style={{ 
                  color: '#ff9800', 
                  textDecoration: 'underline',
                  fontWeight: '600'
                }}
              >
                Recover it here
              </a>
            </p>
          </div>
        </div>
      )}

      {authMethod === 'email' && (
        <div style={{ marginTop: '2rem' }}>
          <h2>Email Verification</h2>
          <label>
            Email Address:
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              style={{ width: '100%', padding: '0.5rem', marginTop: '0.5rem' }}
            />
          </label>
          <button
            onClick={sendEmailCode}
            disabled={loading}
            style={{ marginTop: '1rem', padding: '0.75rem 1.5rem' }}
          >
            {loading ? 'Sending...' : 'Send Verification Code'}
          </button>
        </div>
      )}

      {authMethod === 'email_verify' && (
        <div style={{ marginTop: '2rem' }}>
          <h2>Enter Verification Code</h2>
          <p>Check your email for the verification code sent to {email}</p>
          <label>
            Verification Code:
            <input
              type="text"
              value={code}
              onChange={(e) => setCode(e.target.value)}
              placeholder="6-digit code"
              style={{ width: '100%', padding: '0.5rem', marginTop: '0.5rem' }}
            />
          </label>
          <button
            onClick={verifyEmailCode}
            disabled={loading || code.length !== 6}
            style={{ marginTop: '1rem', padding: '0.75rem 1.5rem' }}
          >
            {loading ? 'Verifying...' : 'Verify Code'}
          </button>
        </div>
      )}

      {authMethod === 'sms' && (
        <div style={{ marginTop: '2rem' }}>
          <h2>SMS/VoIP Verification</h2>
          <label>
            Phone Number:
            <input
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="+1234567890"
              style={{ width: '100%', padding: '0.5rem', marginTop: '0.5rem' }}
            />
          </label>
          <button
            onClick={sendSMSCode}
            disabled={loading}
            style={{ marginTop: '1rem', padding: '0.75rem 1.5rem' }}
          >
            {loading ? 'Sending...' : 'Send Verification Code'}
          </button>
        </div>
      )}

      {authMethod === 'sms_verify' && (
        <div style={{ marginTop: '2rem' }}>
          <h2>Enter Verification Code</h2>
          <p>Check your phone for the verification code sent to {phone}</p>
          <label>
            Verification Code:
            <input
              type="text"
              value={code}
              onChange={(e) => setCode(e.target.value)}
              placeholder="6-digit code"
              style={{ width: '100%', padding: '0.5rem', marginTop: '0.5rem' }}
            />
          </label>
          <button
            onClick={verifySMSCode}
            disabled={loading || code.length !== 6}
            style={{ marginTop: '1rem', padding: '0.75rem 1.5rem' }}
          >
            {loading ? 'Verifying...' : 'Verify Code'}
          </button>
        </div>
      )}
    </main>
  )
}


