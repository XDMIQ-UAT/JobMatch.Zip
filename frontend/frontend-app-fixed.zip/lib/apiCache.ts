/**
 * API Cache Utility
 * Provides caching for API calls to reduce redundant requests
 */

interface CacheEntry<T> {
  data: T
  timestamp: number
}

const cache = new Map<string, CacheEntry<any>>()
const CACHE_DURATION = 5 * 60 * 1000 // 5 minutes

/**
 * Get cached data if valid, otherwise return null
 */
export function getCachedData<T>(key: string): T | null {
  const entry = cache.get(key)
  if (!entry) return null
  
  const now = Date.now()
  if (now - entry.timestamp > CACHE_DURATION) {
    cache.delete(key)
    return null
  }
  
  return entry.data
}

/**
 * Set cached data
 */
export function setCachedData<T>(key: string, data: T): void {
  cache.set(key, {
    data,
    timestamp: Date.now()
  })
}

/**
 * Clear cache for a specific key or all cache
 */
export function clearCache(key?: string): void {
  if (key) {
    cache.delete(key)
  } else {
    cache.clear()
  }
}

/**
 * Fetch user identity with caching
 */
export async function fetchUserIdentity(anonymousId: string): Promise<{
  anonymous_id: string
  provider: string | null
  provider_display_name: string | null
  preferred_language?: string
} | null> {
  const cacheKey = `user_identity_${anonymousId}`
  
  // Check cache first
  const cached = getCachedData<any>(cacheKey)
  if (cached) return cached
  
  // Check sessionStorage
  const sessionData = sessionStorage.getItem('user_identity')
  if (sessionData) {
    try {
      const parsed = JSON.parse(sessionData)
      if (parsed.anonymousId === anonymousId) {
        setCachedData(cacheKey, parsed)
        return parsed
      }
    } catch {
      // Invalid cache
    }
  }
  
  // Fetch from API
  try {
    const response = await fetch(`http://localhost:8000/api/auth/user?anonymous_id=${encodeURIComponent(anonymousId)}`)
    if (!response.ok) return null
    
    const data = await response.json()
    
    // Cache in memory and sessionStorage
    setCachedData(cacheKey, data)
    sessionStorage.setItem('user_identity', JSON.stringify(data))
    
    return data
  } catch (error) {
    console.error('Failed to fetch user identity:', error)
    return null
  }
}

/**
 * Fetch user locale with caching
 */
export async function fetchUserLocale(anonymousId: string): Promise<string | null> {
  const userData = await fetchUserIdentity(anonymousId)
  return userData?.preferred_language || null
}
